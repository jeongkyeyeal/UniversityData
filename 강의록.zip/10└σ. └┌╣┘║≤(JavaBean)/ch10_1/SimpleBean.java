  package ch10.simpleBean;

  public class SimpleBean {
 
    private String msg ;

    public String getMsg() {
      return msg;
    }

    public void setMsg(String msg) {
      this.msg = msg;
    }
  }
