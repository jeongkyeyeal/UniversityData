 package ch10.register; /* WEB-INF - classes에 컴파일시 옆의 경로로 .class파일이 생성된다. */

 public class RegisterBean{
 	
 	private String name; /* 다른 클래스에서 접근을 못하게 private로 지정 */
 	private String age;
 	private String online;
	private String online2;
 	private String address;
	private String address2;
	private String phone;
	private String phone2;
 	private String phone3;
	private String phone4;
	private String phone5;
	private String phone6;

 	public void setName(String name) { /* private로 선언한 this.name에 넘겨받은 name변수 값을 저장 */
 		this.name = name; 
 	}
 
 	public void setAge(String age) {
 		this.age = age; 
 	}
 
 	public void setOnline(String online) {
 		this.online = online; 
 	}
 
 	public void setOnline2(String online2) {
 		this.online2 = online2; 
 	}
	
 	public void setAddress(String address) {
 		this.address = address; 
 	}
 
 	public void setAddress2(String address2) {
 		this.address2 = address2; 
 	}
 	
	public void setPhone(String phone) {
		this.phone = phone; 
 	}
 	
	public void setPhone2(String phone2) {
 		this.phone2 = phone2; 
 	}
	
	public void setPhone3(String phone3) {
 		this.phone3 = phone3; 
 	}

	public void setPhone4(String phone4) {
 		this.phone4 = phone4; 
 	}

	public void setPhone5(String phone5) {
 		this.phone5 = phone5; 
 	}
	
	public void setPhone6(String phone6) {
 		this.phone6 = phone6; 
 	}	
	
 	public String getName() { /* private로 선언한 name의 값을 반환한다. */
 		return name; 
 	}
 
 	public String getAge() {
 		return age; 
 	}
 
 	public String getOnline() {
 		return online; 
 	}
	
 	public String getOnline2() {
 		return online2; 
 	}	
	
 	public String getAddress() {
 		return address; 
 	}
 	
 	public String getAddress2() {
 		return address2; 
 	}
 	
 	public String getPhone() { /* 핸드폰과 전화는 둘다 입력을 안해도 될때를 위해서 */
        if(phone==null) phone=""; /* 입력값이 없으면 null의 값을 가지고 그럴경우 null이아닌 */
        else phone=phone+"-"; /* 공백으로 바꾸어 반환한다. 입력값이 있으면 입력값과 ‘-’부호를 추가하여 리턴한다. */
 		return phone; 
 	}
 
	public String getPhone2() {
		if(phone2==null) phone2="";
		else phone2=phone2+"-";
 		return phone2; 
 	}
  
 	public String getPhone3() {
		if(phone3==null) phone3="";
 		return phone3; 
 	}

 	public String getPhone4() {
		if(phone4==null) phone4="";
		else phone4=phone4+"-";
 		return phone4; 
 	}

 	public String getPhone5() {
		if(phone5==null) phone5="";
		else phone5=phone5+"-";
 		return phone5; 
 	}

 	public String getPhone6() {
		if(phone6==null) phone6="";
 		return phone6; 
 	} 	
 }
